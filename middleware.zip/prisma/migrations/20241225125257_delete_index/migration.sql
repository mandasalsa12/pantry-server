-- DropIndex
DROP INDEX `Storage_category_idx` ON `storage`;

-- DropIndex
DROP INDEX `Storage_name_idx` ON `storage`;
