-- CreateIndex
CREATE INDEX `Storage_category_idx` ON `Storage`(`category`);

-- CreateIndex
CREATE INDEX `Storage_name_idx` ON `Storage`(`name`);
